var express = require('express');
var router = express.Router();
var jsonfile = require('jsonfile')
var myDB = __dirname + "/paras.json"
console.log("BD in: " + myDB)
/* GET home page. */
router.get('/', (req, res) => res.render('index'));

router.get('/para', (req,res) => {
	jsonfile.readFile(myDB, (erro,paras) => {
		if(!erro) res.render('lista', {lista: paras})
		else res.json(erro)
	})
})

router.post('/para/guardar', (req,res) => {
	console.dir("req.body")
  	var p = req.body.para

	jsonfile.readFile(myDB, (erro, paras) => {
    	if(!erro) {
			console.dir(paras)
			paras.push(p)
			jsonfile.writeFile(myDB, paras, erro2 => {
				if(!erro2) console.log("Registo gravado com sucesso")
				else console.log("Erro: "+erro2)
			})
		} else console.log("Erro: " + erro)
	})
	res.json(p)  
})

module.exports = router;
