var http = require('http')

http.createServer(function(req,res) {
    res.writeHead(200,{'Content-Type' : 'text/plain'})
    res.end('Olá turma de 2018!')
    console.log(JSON.stringify(req))
}).listen(7777)